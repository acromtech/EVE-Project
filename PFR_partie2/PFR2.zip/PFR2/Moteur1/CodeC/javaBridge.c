#include <stdio.h>
#include <stdlib.h>
#include "wrapperPFR.h"


#define ATTENTE_REQUETE 	0x01
#define TRAITEMENT 			0x02
#define ENVOI_RESULTATS 	0x03

ResListToSend empilerResultatListe(ResListToSend liste, char* path, int score){
    ResListToSend *tmp = calloc(1, sizeof(ResListToSend));
    tmp->chemin = calloc(100, sizeof(char));
    tmp->score = score;
    strcpy(tmp->chemin, path);
    tmp->next = &liste;
    liste = *tmp;
	return *tmp;
}

int main(int argc, char**argv){
	descripteurEtScoreListe liste_resListToSendTexte = NULL;
    descripteurEtScoreListeImage liste_resListToSendImage = NULL;
    baseDescripteurImage bdImage = initBaseDescripteurImage();
    listeDescripteurImage listeImage = initListeDescripteurImage();
    baseDescripteur bd = initBaseDescripteur();
    pathIdDesc listeDescripteur = initListeDescripteur();
    tableDescript tableDescripteur = NULL;
	resultatAudioScorePath resAudio;
    ResListToSend resListToSend;
    resListToSend.chemin = calloc(1, sizeof(char));
	supprimerDescripteur();

    indexerBaseImage(&bdImage, &listeImage);
    indexationBase("../../BaseFichiersTexte/", &bd, &listeDescripteur, &tableDescripteur);
	printf("Fin Initialisation\n");

	char etat=ATTENTE_REQUETE;
	int boucle=1;
	
	startBus();

	while(boucle){
		switch(etat){
		case ATTENTE_REQUETE:
			sleep(1);
			if(typeTraitement!=-1) etat=TRAITEMENT;
			break;

		case TRAITEMENT:
			switch (typeTraitement){
			case INDEXATION_ALL:
				indexerDescripteur();
				traitementEffectue();
				break;

			case TEXTE_MOTCLE:
				liste_resListToSendTexte = rechercheTexteMotCle(listeDescripteur, tableDescripteur, requete);
				while(liste_resListToSendTexte != NULL){
                    resListToSend = empilerResultatListe(resListToSend, liste_resListToSendTexte->descripteur->path, liste_resListToSendTexte->score);
                    resListToSend.score = liste_resListToSendTexte->score;
					liste_resListToSendTexte = liste_resListToSendTexte->next;
                }
				traitementEffectue();
				break;
			
			case TEXTE_FICHIER:
				liste_resListToSendTexte = rechercheTexteCompare(bd, listeDescripteur, requete);
				while(liste_resListToSendTexte != NULL){
                    resListToSend = empilerResultatListe(resListToSend, liste_resListToSendTexte->descripteur->path, liste_resListToSendTexte->score);
                    resListToSend.score = liste_resListToSendTexte->score;
					liste_resListToSendTexte = liste_resListToSendTexte->next;
                }
				traitementEffectue();
				break;
			
			case IMAGE_MOTCLE:
				liste_resListToSendImage = rechercheCouleur(bdImage, listeImage, requete);
				if(liste_resListToSendTexte == NULL)
					printf("Error\n");
				while(liste_resListToSendTexte != NULL){
                    resListToSend = empilerResultatListe(resListToSend, liste_resListToSendImage->descripteur->path, liste_resListToSendImage->score);
                    resListToSend.score = liste_resListToSendTexte->score;
					liste_resListToSendTexte = liste_resListToSendTexte->next;
                }
				traitementEffectue();
				break;

			case IMAGE_FICHIER:
				liste_resListToSendImage = rechercheHisto(bdImage, listeImage, requete);
				if(liste_resListToSendTexte == NULL)
					printf("Error\n");
				while(liste_resListToSendTexte != NULL){
                    resListToSend = empilerResultatListe(resListToSend, liste_resListToSendImage->descripteur->path, liste_resListToSendImage->score);
                    resListToSend.score = liste_resListToSendTexte->score;
					liste_resListToSendTexte = liste_resListToSendTexte->next;
                }
				traitementEffectue();
				break;

			case SON_FICHIER:
				resAudio = saisieRechercheAudio("jingle_fi.wav");
				traitementEffectue();
				break;
			case SCORE_CHEMIN:
				sendAllResBus(resListToSend);
				traitementEffectue();
				break;
			case STOP_BUS:
				stopBus();
				return 0;
			default:
				printf("\nC\tErreur : Traitement non effectué %x",typeTraitement);
				return 0;
			}
			etat=ATTENTE_REQUETE;
			break;

		default:
			printf("\nC\tErreur : Résultats non envoyés");
			return 0;
		}
	}
	return 0;
}